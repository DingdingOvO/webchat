import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function FeedbackPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // 目前仅展示，不实际发送
    setSent(true);
  }

  if (sent) {
    return (
    <div
      className="anim-fade-in-up"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        gap: 'var(--p4)',
        padding: 'var(--p6)',
      }}
    >
        <svg width="48" height="48" viewBox="0 0 20 20" fill="var(--green)" style={{ opacity: 0.8 }}>
          <path d="M14.8 5.22a.5.5 0 0 1 0 .7l-7.67 7.68a.5.5 0 0 1-.7 0L2.9 10.1a.5.5 0 1 1 .7-.7l3.18 3.18 7.32-7.32a.5.5 0 0 1 .7-.04Z" />
        </svg>
        <h1 style={{ fontSize: 'var(--text-xl)', color: 'var(--text)', fontWeight: 600 }}>感谢反馈</h1>
        <p style={{ color: 'var(--text-muted)', textAlign: 'center', maxWidth: 360 }}>
          你的意见对我们非常重要，我们会认真阅读每一条反馈。
        </p>
        <Link
          to="/"
          style={{
            marginTop: 'var(--p4)',
            padding: '10px 24px',
            background: 'var(--primary)',
            color: 'var(--white)',
            borderRadius: 'var(--r-md)',
            fontWeight: 500,
          }}
        >
          返回首页
        </Link>
      </div>
    );
  }

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(135deg, var(--primary-bg) 0%, var(--aero-100) 100%)',
        padding: 'var(--p6)',
      }}
    >
      <form
        onSubmit={handleSubmit}
        className="anim-fade-in-up"
        style={{
          width: 420,
          maxWidth: '100%',
          padding: 'var(--p10) var(--p8) var(--p6)',
          background: 'var(--bg-surface)',
          borderRadius: 'var(--r-xl)',
          boxShadow: 'var(--shadow-lg)',
        }}
      >
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: 'var(--r-lg)',
            background: 'var(--primary-light)',
            color: 'var(--primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto var(--p4)',
            fontSize: 24,
          }}
        >
          <svg width="24" height="24" viewBox="0 0 20 20" fill="currentColor">
            <path d="M3 5.5A2.5 2.5 0 0 1 5.5 3h9A2.5 2.5 0 0 1 17 5.5v6.88a2.5 2.5 0 0 1-2.5 2.5H9.56l-3.68 2.6A.5.5 0 0 1 5 17.1V14.9a2.5 2.5 0 0 1-2-2.47V5.5ZM5.5 4C4.67 4 4 4.67 4 5.5v6.95c0 .55.45 1 1 1 .28 0 .5.22.5.5v1.44l2.87-2.02a.5.5 0 0 1 .29-.1h4.84c.83 0 1.5-.67 1.5-1.5V5.5c0-.83-.67-1.5-1.5-1.5h-9Z" />
          </svg>
        </div>

        <h1
          style={{
            textAlign: 'center',
            fontSize: 'var(--text-xl)',
            fontWeight: 600,
            color: 'var(--text)',
            marginBottom: 'var(--p1)',
          }}
        >
          反馈建议
        </h1>
        <p
          style={{
            textAlign: 'center',
            fontSize: 'var(--fs-sm)',
            color: 'var(--text-muted)',
            marginBottom: 'var(--p8)',
          }}
        >
          帮助我们做得更好
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--p4)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--p1)' }}>
            <label
              style={{
                fontSize: 'var(--fs-xs)',
                color: 'var(--text-muted)',
                fontWeight: 500,
                paddingLeft: 'var(--p1)',
              }}
            >
              你的名字
            </label>
            <input
              style={{
                width: '100%',
                padding: '10px 14px',
                border: '1.5px solid var(--border)',
                borderRadius: 'var(--r-md)',
                fontSize: 'var(--fs-base)',
                background: 'var(--bg-surface)',
                color: 'var(--text)',
                outline: 'none',
                transition: 'border-color 0.15s var(--ease), box-shadow 0.15s var(--ease)',
                boxSizing: 'border-box',
              }}
              type="text"
              placeholder="你的名字"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onFocus={(e) => {
                e.target.style.borderColor = 'var(--primary)';
                e.target.style.boxShadow = '0 0 0 3px var(--aero-200)';
              }}
              onBlur={(e) => {
                e.target.style.borderColor = 'var(--border)';
                e.target.style.boxShadow = 'none';
              }}
              required
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--p1)' }}>
            <label
              style={{
                fontSize: 'var(--fs-xs)',
                color: 'var(--text-muted)',
                fontWeight: 500,
                paddingLeft: 'var(--p1)',
              }}
            >
              邮箱（可选）
            </label>
            <input
              style={{
                width: '100%',
                padding: '10px 14px',
                border: '1.5px solid var(--border)',
                borderRadius: 'var(--r-md)',
                fontSize: 'var(--fs-base)',
                background: 'var(--bg-surface)',
                color: 'var(--text)',
                outline: 'none',
                transition: 'border-color 0.15s var(--ease), box-shadow 0.15s var(--ease)',
                boxSizing: 'border-box',
              }}
              type="email"
              placeholder="方便我们回复你"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onFocus={(e) => {
                e.target.style.borderColor = 'var(--primary)';
                e.target.style.boxShadow = '0 0 0 3px var(--aero-200)';
              }}
              onBlur={(e) => {
                e.target.style.borderColor = 'var(--border)';
                e.target.style.boxShadow = 'none';
              }}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--p1)' }}>
            <label
              style={{
                fontSize: 'var(--fs-xs)',
                color: 'var(--text-muted)',
                fontWeight: 500,
                paddingLeft: 'var(--p1)',
              }}
            >
              反馈内容
            </label>
            <textarea
              style={{
                width: '100%',
                padding: '10px 14px',
                border: '1.5px solid var(--border)',
                borderRadius: 'var(--r-md)',
                fontSize: 'var(--fs-base)',
                background: 'var(--bg-surface)',
                color: 'var(--text)',
                outline: 'none',
                minHeight: 120,
                resize: 'vertical',
                fontFamily: 'inherit',
                transition: 'border-color 0.15s var(--ease), box-shadow 0.15s var(--ease)',
                boxSizing: 'border-box',
              }}
              placeholder="告诉我们你的想法..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onFocus={(e) => {
                e.target.style.borderColor = 'var(--primary)';
                e.target.style.boxShadow = '0 0 0 3px var(--aero-200)';
              }}
              onBlur={(e) => {
                e.target.style.borderColor = 'var(--border)';
                e.target.style.boxShadow = 'none';
              }}
              required
            />
          </div>

          <button
            type="submit"
            disabled={!name.trim() || !message.trim()}
            style={{
              width: '100%',
              padding: '11px',
              background: 'var(--primary)',
              color: 'var(--white)',
              border: 'none',
              borderRadius: 'var(--r-md)',
              fontSize: 'var(--fs-md)',
              fontWeight: 500,
              cursor: 'pointer',
              marginTop: 'var(--p2)',
              transition: 'all 0.15s var(--ease)',
              opacity: !name.trim() || !message.trim() ? 0.5 : 1,
            }}
            onMouseEnter={(e) => {
              if (name.trim() && message.trim()) {
                e.currentTarget.style.background = 'var(--primary-hover)';
                e.currentTarget.style.transform = 'translateY(-1px)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'var(--primary)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            发送反馈
          </button>
        </div>

        <p
          style={{
            textAlign: 'center',
            fontSize: 'var(--fs-sm)',
            color: 'var(--text-muted)',
            marginTop: 'var(--p6)',
          }}
        >
          <Link to="/" style={{ color: 'var(--primary)', fontWeight: 500 }}>
            返回首页
          </Link>
        </p>
      </form>
    </div>
  );
}
