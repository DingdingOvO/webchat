import { memo, useEffect, useRef } from 'react';
import type { MessageDTO } from '../types';
import styles from './MessageList.module.css';

interface Props {
  messages: MessageDTO[];
  userId: number;
  contactType: 'p2p' | 'group';
}

function MessageListInner({ messages, userId, contactType }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (messages.length === 0) {
    return (
      <div className={styles.emptyState}>
        <svg width="48" height="48" viewBox="0 0 20 20" fill="currentColor" opacity="0.3">
          <path d="M3 5.5A2.5 2.5 0 0 1 5.5 3h9A2.5 2.5 0 0 1 17 5.5v6.88a2.5 2.5 0 0 1-2.5 2.5H9.56l-3.68 2.6A.5.5 0 0 1 5 17.1V14.9a2.5 2.5 0 0 1-2-2.47V5.5ZM5.5 4C4.67 4 4 4.67 4 5.5v6.95c0 .55.45 1 1 1 .28 0 .5.22.5.5v1.44l2.87-2.02a.5.5 0 0 1 .29-.1h4.84c.83 0 1.5-.67 1.5-1.5V5.5c0-.83-.67-1.5-1.5-1.5h-9Z" />
        </svg>
        <span>暂无消息，发送第一条消息吧</span>
      </div>
    );
  }

  return (
    <div className={styles.wrapper}>
      {messages.map((m, idx) => {
        const isMe = m.senderId === userId;
        const showSender = contactType === 'group' && !isMe;
        const prevMsg = idx > 0 ? messages[idx - 1] : null;
        const isCompact = prevMsg && prevMsg.senderId === m.senderId;
        const showDateSep = prevMsg && new Date(m.createdAt).toDateString() !== new Date(prevMsg.createdAt).toDateString();

        return (
          <div key={m.id || `${m.createdAt}-${m.senderId}-${idx}`}>
            {/* 日期分割线 */}
            {showDateSep && (
              <div className={styles.dateSeparator}>
                <span className={styles.dateSeparatorLine} />
                <span className={styles.dateSeparatorText}>
                  {new Date(m.createdAt).toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' })}
                </span>
                <span className={styles.dateSeparatorLine} />
              </div>
            )}

            <div
              className={`${styles.messageRow} ${isMe ? styles.isMe : styles.isOther} ${isCompact ? styles.compact : ''}`}
              style={{ animationDelay: `${Math.min(idx * 30, 300)}ms` }}
            >
              {showSender && <span className={styles.senderName}>{m.senderName}</span>}
              <div className={`${styles.bubble} ${isMe ? styles.bubbleMine : styles.bubbleOther}`}>
                {m.content}
              </div>
              <span className={styles.time}>
                {new Date(m.createdAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        );
      })}
      <div ref={bottomRef} />
    </div>
  );
}

export const MessageList = memo(MessageListInner);
