import styles from './Skeleton.module.css';

/* 会话列表骨架屏 */
export function ConvListSkeleton() {
  return (
    <>
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className={styles.convSkeleton}>
          <div className={styles.convSkeletonAvatar} />
          <div className={styles.convSkeletonLines}>
            <div className={styles.convSkeletonLine1} />
            <div className={styles.convSkeletonLine2} />
          </div>
        </div>
      ))}
    </>
  );
}

/* 消息区域骨架屏 */
export function MessageSkeleton() {
  return (
    <div className={styles.messageSkeleton}>
      {Array.from({ length: 4 }).map((_, i) => (
        <div
          key={i}
          className={`${styles.messageSkeletonRow} ${i % 2 === 1 ? styles.messageSkeletonRowOwn : ''}`}
        >
          <div
            className={`${styles.messageSkeletonBubble} ${i % 2 === 1 ? styles.messageSkeletonBubbleNarrow : ''}`}
          />
        </div>
      ))}
    </div>
  );
}
