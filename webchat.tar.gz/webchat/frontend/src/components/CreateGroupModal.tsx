import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import type { GroupDTO, UserDTO } from '../types';
import styles from './CreateGroupModal.module.css';

interface Props {
  readonly friends: UserDTO[];
  readonly onClose: () => void;
  readonly onCreated: (g: GroupDTO) => void;
}

export default function CreateGroupModal({ friends, onClose, onCreated }: Props) {
  const { auth } = useAuth();
  const [name, setName] = useState('');
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function toggle(id: number) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }

  async function handleCreate() {
    if (!name.trim() || !auth) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${auth.token}` },
        body: JSON.stringify({ name: name.trim(), memberIds: [...selected] }),
      });
      if (!res.ok) {
        const data: Record<string, string> = await res.json().catch(() => ({}));
        setError(data.error || '创建失败');
        return;
      }
      const group: GroupDTO = await res.json();
      onCreated(group);
      onClose();
    } catch {
      setError('网络错误，请重试');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className={styles.overlay}
      onClick={onClose}
      onKeyDown={(e) => {
        if (e.key === 'Escape') onClose();
      }}
      role="dialog"
      tabIndex={-1}
    >
      <div
        className={styles.modal}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <h2 className={styles.title}>创建群组</h2>

        {error && <p className={styles.error}>{error}</p>}

        <input
          className={styles.input}
          type="text"
          placeholder="群组名称"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <div className={styles.friendList}>
          {friends.length === 0 ? (
            <p className={styles.emptyFriends}>暂无好友</p>
          ) : (
            friends.map((f) => (
              <label key={f.id} className={styles.friendItem}>
                <input
                  className={styles.friendItemCheckbox}
                  type="checkbox"
                  checked={selected.has(f.id)}
                  onChange={() => toggle(f.id)}
                />
                {f.nickname || f.username}
              </label>
            ))
          )}
        </div>

        <div className={styles.actions}>
          <button className={styles.cancelBtn} onClick={onClose}>
            取消
          </button>
          <button
            className={styles.createBtn}
            onClick={handleCreate}
            disabled={loading || !name.trim()}
          >
            {loading ? '创建中...' : '创建'}
          </button>
        </div>
      </div>
    </div>
  );
}
